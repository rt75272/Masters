# Critical Thinking 1.1 - Face Detection

### Unprocessed input image
![Input Image](input_image.jpg)
===

### Program Execution
![Code Execution 00](code_execution_00.png)  
![Code Execution 01](code_execution_01.png)  
===

### Processed Output Image
![Output Image](output_image.jpg)  
===