# --------------------------------------------------------------------------------------
# Chatty Chatbot - API Key
#
# OpenAI API key storage.
#
# Usage:
#   from api_key import API_KEY
# --------------------------------------------------------------------------------------
API_KEY = (
    "sk-proj-la5CuVlwofszwsEKXLdJHXNCbsn3WJVYLWIqlSTv1xmt0_4TkVf4LGM1PcpQ46-"
    "MOKBL1-VNSmT3BlbkFJUolts0D19yIINrUPIYTrdiRCG4qMNBtz9jq8X5HY381sIEab9h3n"
    "ezcpWVuyTqtIkGN4mgn1MA"
)